import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Logo, Bird } from "@/components/Logo";
import p1 from "@/assets/p1.jpg";
import p2 from "@/assets/p2.jpg";
import p3 from "@/assets/p3.jpg";
import p4 from "@/assets/p4.jpg";

const TITLE = "Eleev — Desenvolvimento Web, IA e Automação";
const DESC =
  "A Eleev cria sites, aplicações web, agentes de IA e automações para empresas que querem crescer através da tecnologia.";
const WHATSAPP = "5500000000000"; // TODO: número real
const EMAIL = "contato@eleev.com.br";
const wa = (msg = "Olá, Eleev! Quero conversar sobre um projeto.") =>
  `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const NAV = [
  ["Início", "#inicio"],
  ["Serviços", "#servicos"],
  ["Como funciona", "#como-funciona"],
  ["Projetos", "#projetos"],
  ["Sobre", "#sobre"],
  ["Contato", "#contato"],
] as const;

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in"), io.unobserve(e.target))),
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function Arrow() {
  return <span aria-hidden className="inline-block transition-transform group-hover:translate-x-1">→</span>;
}

function BtnPrimary({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a href={href} className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition hover:glow-primary hover:-translate-y-0.5">
      {children}
    </a>
  );
}
function BtnGhost({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a href={href} className="group inline-flex items-center gap-2 rounded-full border border-border px-6 py-3.5 text-sm font-semibold transition hover:border-primary hover:text-primary">
      {children}
    </a>
  );
}
function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-5 inline-flex items-center gap-2 font-display text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">
      <span className="h-1.5 w-1.5 rounded-full bg-primary" /> {children}
    </p>
  );
}

function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 20);
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all ${scrolled || open ? "border-b border-border bg-background/75 backdrop-blur-xl" : ""}`}>
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 py-4 md:px-8">
        <a href="#inicio" className="shrink-0"><Logo /></a>
        <nav className="hidden items-center gap-8 lg:flex" aria-label="Principal">
          {NAV.map(([l, h]) => (
            <a key={h} href={h} className="text-sm text-muted-foreground transition hover:text-foreground">{l}</a>
          ))}
        </nav>
        <div className="hidden lg:block"><BtnPrimary href="#contato">Fale com a Eleev</BtnPrimary></div>
        <button onClick={() => setOpen(!open)} className="relative h-10 w-10 lg:hidden" aria-label="Menu" aria-expanded={open}>
          <span className={`absolute left-2 right-2 h-px bg-foreground transition ${open ? "top-5 rotate-45" : "top-4"}`} />
          <span className={`absolute left-2 right-2 h-px bg-foreground transition ${open ? "top-5 -rotate-45" : "top-6"}`} />
        </button>
      </div>
      {open && (
        <nav className="flex flex-col gap-1 px-5 pb-8 lg:hidden">
          {NAV.map(([l, h]) => (
            <a key={h} href={h} onClick={() => setOpen(false)} className="border-b border-border py-4 font-display text-2xl">{l}</a>
          ))}
          <div className="mt-6"><BtnPrimary href="#contato">Fale com a Eleev <Arrow /></BtnPrimary></div>
        </nav>
      )}
    </header>
  );
}

function HeroVisual() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[520px]">
      <div className="absolute inset-0 animate-spin-slow rounded-full border border-dashed border-border" />
      <div className="absolute inset-[12%] rounded-full border border-border" />
      <div className="absolute inset-[28%] rounded-full bg-primary/10 blur-3xl" />
      <Bird className="absolute inset-[22%] h-[56%] w-[56%] animate-float drop-shadow-2xl" />
      <div className="absolute left-0 top-[14%] animate-float rounded-2xl border border-border bg-card/80 p-4 backdrop-blur" style={{ animationDelay: "-2s" }}>
        <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Agente IA</p>
        <p className="mt-1 flex items-center gap-2 font-display text-sm"><span className="h-2 w-2 animate-pulse rounded-full bg-primary" />Leads qualificados</p>
      </div>
      <div className="absolute bottom-[12%] right-0 animate-float rounded-2xl border border-border bg-card/80 p-4 backdrop-blur" style={{ animationDelay: "-4s" }}>
        <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Performance</p>
      </div>
      <div className="absolute bottom-[30%] left-[4%] rounded-full border border-border bg-card/80 px-4 py-2 font-mono text-xs backdrop-blur">
        automação.run() <span className="text-primary">✓</span>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <section id="inicio" className="relative overflow-hidden pt-32 pb-20 md:pt-40">
      <div className="pointer-events-none absolute inset-0 grid-bg [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-[1.15fr_1fr]">
        <div className="reveal">
          <p className="mb-8 inline-flex items-center gap-3 rounded-full border border-border px-4 py-1.5 font-display text-xs tracking-widest">
            <span className="text-primary">WEB</span>+<span className="text-primary">IA</span>+<span className="text-primary">AUTOMAÇÃO</span>
          </p>
          <h1 className="text-5xl font-semibold leading-[0.95] sm:text-6xl lg:text-7xl xl:text-8xl">
            Seu negócio.<br />
            <span className="text-muted-foreground">Elevado pela</span><br />
            tecnologia<span className="text-primary">.</span>
          </h1>
          <p className="mt-8 max-w-xl text-lg text-muted-foreground">
            Construímos experiências digitais, sites e agentes de IA que transformam processos, melhoram operações e ajudam negócios a crescer.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <BtnPrimary href="#contato">Quero transformar meu negócio <Arrow /></BtnPrimary>
            <BtnGhost href="#servicos">Conhecer soluções</BtnGhost>
          </div>
          <p className="mt-10 text-xs uppercase tracking-[0.2em] text-muted-foreground">
            Desenvolvimento Web <span className="text-primary">•</span> Agentes de IA <span className="text-primary">•</span> Automação
          </p>
        </div>
        <div className="reveal"><HeroVisual /></div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = ["Sites", "Landing pages", "Sistemas web", "Agentes de IA", "Automação", "Integrações", "APIs", "SEO técnico"];
  return (
    <div className="overflow-hidden border-y border-border py-5">
      <div className="flex w-max animate-marquee gap-12 font-display text-2xl text-muted-foreground">
        {[...items, ...items].map((t, i) => (
          <span key={i} className="flex items-center gap-12">{t} <span className="text-primary">✦</span></span>
        ))}
      </div>
    </div>
  );
}

function ServiceCard({ title, text, items, cta, msg }: { title: string; text: string; items: string[]; cta: string; msg: string }) {
  return (
    <article className="reveal group relative overflow-hidden rounded-3xl border border-border bg-card p-8 transition duration-500 hover:-translate-y-1 hover:border-primary/50 md:p-10">
      <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-primary/0 blur-3xl transition duration-700 group-hover:bg-primary/15" />
      <div className="relative">
        <p className="text-right font-display text-xs uppercase tracking-widest text-muted-foreground">Eleev</p>
        <h3 className="mt-16 text-4xl font-semibold md:text-5xl">{title}</h3>
        <p className="mt-4 max-w-md text-muted-foreground">{text}</p>
        <ul className="mt-8 flex flex-wrap gap-2">
          {items.map((i) => (
            <li key={i} className="rounded-full border border-border px-3 py-1.5 text-xs">{i}</li>
          ))}
        </ul>
        <a href={wa(msg)} target="_blank" rel="noreferrer" className="group/l mt-10 inline-flex items-center gap-2 font-semibold text-primary">
          {cta} <span className="transition-transform group-hover/l:translate-x-1">→</span>
        </a>
      </div>
    </article>
  );
}

function Services() {
  return (
    <section id="servicos" className="mx-auto max-w-7xl px-5 py-28 md:px-8">
      <div className="reveal mb-14 grid gap-6 md:grid-cols-2 md:items-end">
        <div>
          <Eyebrow>O que a Eleev faz</Eyebrow>
          <h2 className="text-4xl font-semibold md:text-6xl">Tecnologia que resolve problemas reais.</h2>
        </div>
        <p className="max-w-md text-lg text-muted-foreground md:justify-self-end">
          Não criamos tecnologia apenas para parecer moderna. Criamos soluções digitais pensadas para gerar resultado.
        </p>
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <ServiceCard title="Web Development" msg="Olá! Quero criar meu projeto web."
          text="Sites, landing pages e aplicações web rápidas, responsivas e pensadas para transformar visitantes em clientes."
          items={["Sites institucionais", "Landing pages", "E-commerce", "Sistemas web", "Integrações", "SEO técnico", "Performance"]}
          cta="Criar meu projeto" />
        <ServiceCard title="AI Agents" msg="Olá! Quero automatizar meu negócio com IA."
          text="Agentes de IA que executam tarefas, automatizam processos e ajudam sua empresa a trabalhar de forma mais inteligente."
          items={["Atendimento automatizado", "Qualificação de leads", "Processamento de informações", "Automação de tarefas", "Integração com APIs", "Fluxos inteligentes", "Agentes personalizados"]}
          cta="Automatizar meu negócio" />
      </div>
    </section>
  );
}

function Differential() {
  const nodes = [
    ["Design", "top-0 left-1/2 -translate-x-1/2"],
    ["Código", "top-1/2 right-0 -translate-y-1/2"],
    ["IA", "bottom-0 left-1/2 -translate-x-1/2"],
    ["Automação", "top-1/2 left-0 -translate-y-1/2"],
  ];
  return (
    <section id="sobre" className="bg-paper text-paper-foreground">
      <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 py-28 md:px-8 lg:grid-cols-2">
        <div className="reveal">
          <p className="mb-5 font-display text-xs uppercase tracking-[0.2em] opacity-60">Diferencial</p>
          <h2 className="text-4xl font-semibold leading-[1] md:text-6xl">
            Menos tarefas repetitivas.<br />Mais tecnologia trabalhando por você.
          </h2>
          <p className="mt-8 max-w-lg text-lg opacity-70">
            A Eleev é um estúdio de tecnologia jovem e técnico. Unimos quatro disciplinas num só time para entregar produtos digitais que funcionam — do primeiro pixel à última integração.
          </p>
          <p className="mt-8 font-display text-lg font-semibold tracking-wide">DESIGN + CÓDIGO + IA + AUTOMAÇÃO</p>
        </div>
        <div className="reveal relative mx-auto aspect-square w-full max-w-md">
          <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full" fill="none" aria-hidden>
            <path d="M200 40 L360 200 L200 360 L40 200 Z M200 40 L200 360 M40 200 L360 200" stroke="currentColor" strokeOpacity=".25" strokeWidth="1.5" />
            <circle cx="200" cy="200" r="120" stroke="currentColor" strokeOpacity=".15" strokeDasharray="4 6" />
          </svg>
          <div className="absolute left-1/2 top-1/2 grid h-28 w-28 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-paper-foreground font-logo text-2xl text-primary">eleev</div>
          {nodes.map(([l, pos]) => (
            <div key={l} className={`absolute ${pos} rounded-full border border-paper-foreground/20 bg-paper px-5 py-3 font-display font-semibold transition hover:bg-paper-foreground hover:text-primary`}>{l}</div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Steps() {
  const steps = [
    ["Descoberta", "Entendemos seu negócio, seus objetivos e os problemas que precisam ser resolvidos."],
    ["Estratégia", "Definimos a melhor solução, tecnologia e estrutura para o projeto."],
    ["Construção", "Desenvolvemos o site, sistema, automação ou agente de IA."],
    ["Testes", "Validamos performance, responsividade, integrações e funcionamento."],
    ["Evolução", "Publicamos, acompanhamos e continuamos melhorando a solução."],
  ];
  return (
    <section id="como-funciona" className="mx-auto max-w-7xl px-5 py-28 md:px-8">
      <div className="reveal mb-16">
        <Eyebrow>Como funciona</Eyebrow>
        <h2 className="text-4xl font-semibold md:text-6xl">Do problema à solução.</h2>
      </div>
      <ol className="relative grid gap-10 lg:grid-cols-5 lg:gap-6">
        <div className="absolute left-[11px] top-2 bottom-2 w-px bg-gradient-to-b from-primary via-border to-transparent lg:left-0 lg:right-0 lg:top-[11px] lg:bottom-auto lg:h-px lg:w-auto lg:bg-gradient-to-r" />
        {steps.map(([t, d], i) => (
          <li key={t} className="reveal group relative pl-10 lg:pl-0 lg:pt-12" style={{ transitionDelay: `${i * 80}ms` }}>
            <span className="absolute left-0 top-0 grid h-6 w-6 place-items-center rounded-full border border-primary bg-background transition group-hover:bg-primary">
              <span className="h-2 w-2 rounded-full bg-primary group-hover:bg-primary-foreground" />
            </span>
            <h3 className="mt-2 text-2xl font-semibold">{t}</h3>
            <p className="mt-3 text-sm text-muted-foreground">{d}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}

function Projects() {
  const projects = [
    { img: p1, name: "Evergreen", cat: "Web", desc: "Site institucional com reservas online para restaurante autoral.", tech: ["React", "SEO", "CMS"] },
    { img: p2, name: "Atende.ai", cat: "IA", desc: "Agente de atendimento que responde clientes e agenda horários 24/7.", tech: ["LLM", "WhatsApp", "API"] },
    { img: p3, name: "FlowForge", cat: "Automação", desc: "Orquestrador de onboarding que conecta CRM, e-mail e SMS.", tech: ["Webhooks", "CRM", "Node"] },
    { img: p4, name: "FlexFit", cat: "Landing Page", desc: "Landing page de lançamento com foco total em conversão.", tech: ["Next", "A/B", "Analytics"] },
  ];
  return (
    <section id="projetos" className="border-t border-border py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="reveal mb-14 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <Eyebrow>Projetos</Eyebrow>
            <h2 className="text-4xl font-semibold md:text-6xl">Projetos que saem do papel.</h2>
          </div>
          <p className="font-display text-sm text-muted-foreground">Web / Landing Page / Automação / IA</p>
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          {projects.map((p) => (
            <article key={p.name} className="reveal group overflow-hidden rounded-3xl border border-border bg-card transition duration-500 hover:border-primary/50">
              <div className="overflow-hidden">
                <img src={p.img} alt={`Projeto ${p.name} — ${p.cat}`} width={1280} height={896} loading="lazy" className="aspect-[16/11] w-full object-cover transition duration-700 group-hover:scale-105" />
              </div>
              <div className="p-7">
                <div className="flex items-center justify-between gap-4">
                  <h3 className="text-2xl font-semibold">{p.name}</h3>
                  <span className="shrink-0 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">{p.cat}</span>
                </div>
                <p className="mt-3 text-muted-foreground">{p.desc}</p>
                <p className="mt-5 font-mono text-xs text-muted-foreground">{p.tech.join(" · ")}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Agents() {
  const ex = [
    ["Atendimento", "Responde perguntas e direciona clientes."],
    ["Vendas", "Qualifica leads e identifica oportunidades."],
    ["Operações", "Automatiza tarefas repetitivas e processos internos."],
    ["Dados", "Organiza, analisa e transforma informações em ações."],
    ["Integrações", "Conecta sistemas, APIs e ferramentas."],
  ];
  return (
    <section className="relative overflow-hidden border-t border-border py-28">
      <div className="pointer-events-none absolute -right-40 top-20 h-[500px] w-[500px] rounded-full bg-primary/10 blur-[120px]" />
      <div className="relative mx-auto grid max-w-7xl gap-16 px-5 md:px-8 lg:grid-cols-[1fr_1.1fr]">
        <div className="reveal lg:sticky lg:top-32 lg:self-start">
          <Eyebrow>Agentes de IA</Eyebrow>
          <h2 className="text-4xl font-semibold md:text-6xl">E se sua empresa tivesse um funcionário digital?</h2>
          <p className="mt-6 max-w-md text-lg text-muted-foreground">
            Agentes de IA podem analisar informações, tomar decisões dentro de regras definidas, utilizar ferramentas e executar tarefas automaticamente.
          </p>
          <div className="mt-10"><BtnPrimary href={wa("Olá! Quero um agente de IA.")}>Quero um agente de IA <Arrow /></BtnPrimary></div>
        </div>
        <ul className="flex flex-col">
          {ex.map(([t, d]) => (
            <li key={t} className="reveal group flex items-baseline gap-6 border-b border-border py-8 transition hover:pl-3">
              <div>
                <h3 className="text-3xl font-semibold transition group-hover:text-primary">{t}</h3>
                <p className="mt-2 text-muted-foreground">{d}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Audience() {
  const a = ["Pequenas empresas", "Prestadores de serviço", "Comércio", "Profissionais autônomos", "Empresas em crescimento", "Negócios que querem automatizar processos"];
  return (
    <section className="mx-auto max-w-7xl px-5 py-28 md:px-8">
      <div className="reveal mb-14 max-w-3xl">
        <Eyebrow>Para quem é</Eyebrow>
        <h2 className="text-4xl font-semibold md:text-6xl">Tecnologia para negócios que querem evoluir.</h2>
      </div>
      <div className="grid gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
        {a.map((t) => (
          <div key={t} className="reveal group bg-background p-8 transition hover:bg-card">
            <h3 className="mt-10 text-xl font-semibold">{t}</h3>
          </div>
        ))}
      </div>
      <p className="reveal mt-10 max-w-2xl text-lg text-muted-foreground">
        Se existe um processo repetitivo, uma oportunidade digital ou uma experiência que pode ser melhorada, provavelmente existe uma solução.
      </p>
    </section>
  );
}

function Maintenance() {
  const items = [
    ["Manutenção", "Correções, atualizações e acompanhamento."],
    ["Otimização", "Performance, SEO e melhorias de conversão."],
    ["Evolução", "Novas páginas, funcionalidades, integrações e automações."],
  ];
  return (
    <section className="border-t border-border py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="reveal grid gap-8 md:grid-cols-2 md:items-end">
          <h2 className="text-4xl font-semibold md:text-6xl">Seu projeto não termina quando entra no ar.</h2>
          <p className="text-lg text-muted-foreground">
            A Eleev pode continuar ao seu lado com manutenção, melhorias, otimização, novas funcionalidades, automações e evolução contínua.
          </p>
        </div>
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {items.map(([t, d]) => (
            <div key={t} className="reveal rounded-3xl border border-border bg-card p-8 transition hover:-translate-y-1 hover:border-primary/50">
              <h3 className="text-2xl font-semibold">{t}</h3>
              <p className="mt-3 text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
        <div className="reveal mt-10"><BtnGhost href={wa("Olá! Quero conhecer os planos de manutenção.")}>Conhecer planos <Arrow /></BtnGhost></div>
      </div>
    </section>
  );
}

const TYPES = ["Site", "Landing Page", "Sistema Web", "Agente de IA", "Automação", "Outro"];

function Contact() {
  const [type, setType] = useState("Site");
  const [sent, setSent] = useState(false);
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const msg = `Olá, Eleev!\nNome: ${f.get("nome")}\nEmpresa: ${f.get("empresa") || "-"}\nWhatsApp: ${f.get("whatsapp")}\nE-mail: ${f.get("email")}\nTipo de projeto: ${type}\n\n${f.get("mensagem")}`;
    window.open(wa(msg), "_blank");
    setSent(true);
  };
  const input = "w-full rounded-xl border border-input bg-background px-4 py-3.5 text-sm outline-none transition placeholder:text-muted-foreground focus:border-primary";
  return (
    <section id="contato" className="relative overflow-hidden border-t border-border py-28">
      <div className="pointer-events-none absolute inset-0 grid-bg [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_70%)]" />
      <div className="relative mx-auto grid max-w-7xl gap-16 px-5 md:px-8 lg:grid-cols-2">
        <div className="reveal">
          <h2 className="text-5xl font-semibold leading-[0.95] md:text-7xl">
            Pronto para elevar seu negócio<span className="text-primary">?</span>
          </h2>
          <p className="mt-8 max-w-md text-lg text-muted-foreground">
            Conte o que você precisa. A Eleev transforma ideias, problemas e processos em soluções digitais.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <BtnPrimary href="#form">Falar com a Eleev <Arrow /></BtnPrimary>
            <BtnGhost href={wa()}>WhatsApp</BtnGhost>
          </div>
        </div>
        <form id="form" onSubmit={submit} className="reveal grid gap-4 rounded-3xl border border-border bg-card p-6 md:p-8">
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="grid gap-2 text-xs text-muted-foreground">Nome<input required name="nome" maxLength={100} className={input} placeholder="Seu nome" /></label>
            <label className="grid gap-2 text-xs text-muted-foreground">Empresa<input name="empresa" maxLength={100} className={input} placeholder="Nome da empresa" /></label>
            <label className="grid gap-2 text-xs text-muted-foreground">WhatsApp<input required name="whatsapp" type="tel" maxLength={20} className={input} placeholder="(00) 00000-0000" /></label>
            <label className="grid gap-2 text-xs text-muted-foreground">E-mail<input required name="email" type="email" maxLength={255} className={input} placeholder="voce@empresa.com" /></label>
          </div>
          <fieldset className="grid gap-2">
            <legend className="mb-2 text-xs text-muted-foreground">Tipo de projeto</legend>
            <div className="flex flex-wrap gap-2">
              {TYPES.map((t) => (
                <button type="button" key={t} onClick={() => setType(t)} aria-pressed={type === t}
                  className={`rounded-full border px-4 py-2 text-sm transition ${type === t ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary"}`}>{t}</button>
              ))}
            </div>
          </fieldset>
          <label className="grid gap-2 text-xs text-muted-foreground">Mensagem<textarea required name="mensagem" rows={4} maxLength={1000} className={input} placeholder="Conte um pouco sobre o projeto" /></label>
          <button className="group mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-4 font-semibold text-primary-foreground transition hover:glow-primary">
            Enviar mensagem <Arrow />
          </button>
          {sent && <p className="text-sm text-primary" role="status">Abrimos o WhatsApp com sua mensagem. Até já!</p>}
        </form>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto max-w-7xl px-5 py-16 md:px-8">
        <div className="grid gap-12 md:grid-cols-[2fr_1fr_1fr]">
          <div>
            <Logo className="[&>span:first-child]:text-5xl [&_svg]:h-12" />
            <p className="mt-6 font-display text-lg text-muted-foreground">Web. IA. Automação. Evolução.</p>
          </div>
          <nav className="grid content-start gap-3 text-sm" aria-label="Rodapé">
            {NAV.filter(([l]) => l !== "Como funciona").map(([l, h]) => <a key={h} href={h} className="text-muted-foreground hover:text-primary">{l}</a>)}
          </nav>
          <div className="grid content-start gap-3 text-sm">
            <a href={wa()} className="text-muted-foreground hover:text-primary">WhatsApp</a>
            <a href={`mailto:${EMAIL}`} className="text-muted-foreground hover:text-primary">E-mail</a>
            <a href="https://instagram.com" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary">Instagram</a>
            <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary">LinkedIn</a>
          </div>
        </div>
        <p className="mt-16 border-t border-border pt-8 text-xs text-muted-foreground">© 2026 Eleev. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}

function FloatingWhatsApp() {
  return (
    <a href={wa()} target="_blank" rel="noreferrer" aria-label="Falar no WhatsApp"
      className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground transition hover:scale-105 glow-primary">
      <svg viewBox="0 0 24 24" className="h-6 w-6" fill="currentColor" aria-hidden><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2c-1.5 0-3-.4-4.3-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2c0 1.3.9 2.5 1 2.7.1.2 1.8 2.8 4.4 3.9 1.6.7 2.3.8 3.1.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.5-.3Z"/></svg>
    </a>
  );
}

function Index() {
  useReveal();
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Marquee />
        <Services />
        <Differential />
        <Steps />
        <Projects />
        <Agents />
        <Audience />
        <Maintenance />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
