export function Bird({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 200 130" className={className} fill="none" strokeWidth="3.5" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 5 L110 15 L75 80 Z" className="stroke-brand-cyan" />
      <path d="M2 22 L60 30 L105 115 L92 70 Z" className="stroke-foreground" />
      <path d="M110 15 L130 60 L170 60 L105 115 L25 105 L75 80" className="stroke-brand-pink" />
      <path d="M130 60 L95 60 L92 70 L130 60 L150 55 L135 30 L155 28 L165 55" className="stroke-brand-cyan" />
      <path d="M165 22 L195 38 L162 38 Z" className="stroke-brand-pink" />
    </svg>
  );
}

export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 ${className}`} aria-label="Eleev">
      <span className="font-logo text-2xl font-light tracking-tight">eleev</span>
      <Bird className="h-6 w-auto" />
    </span>
  );
}
