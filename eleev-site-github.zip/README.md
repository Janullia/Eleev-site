# Eleev — Site institucional

Site da Eleev: desenvolvimento web, agentes de IA e automação.

Página única em português, com tema escuro, acentos em verde-limão e formulário de contato que envia a mensagem direto para o WhatsApp.

## Desenvolvimento

Requisitos: Node.js 20+ (ou Bun).

```sh
npm install
npm run dev      # servidor de desenvolvimento em http://localhost:8080
npm run build    # build de produção
npm run preview  # serve o build de produção
npm run test     # testes (vitest)
npm run lint     # eslint + prettier
```

## Estrutura

```
src/
  routes/index.tsx   # página completa (todas as seções)
  routes/__root.tsx  # layout raiz, fontes e metadados
  components/Logo.tsx# logo e pássaro (SVG)
  styles.css         # tema (Tailwind CSS v4): cores, fontes, animações
  assets/            # imagens dos projetos
public/              # favicon, robots.txt, sitemap.xml
```

## Antes de publicar

Os dados de contato são placeholders. Troque em `src/routes/index.tsx`, nas constantes do topo do arquivo:

- `WHATSAPP` — número do WhatsApp (formato: 55 + DDD + número)
- `EMAIL` — e-mail de contato
- Links de Instagram e LinkedIn no componente `Footer`

## Stack

- TanStack Start (React 19, SSR)
- Tailwind CSS v4
- TypeScript
